

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include "image.h"
#include "stdio-wrapper.h"
#include "haar.h"

#define INPUT_FILENAME "640.pgm"
#define OUTPUT_FILENAME "Output.pgm"

using namespace std;


int main (int argc, char *argv[]) 
{

   char *logFile, *inFile;
   
   if(argc > 2){
      logFile = argv[2];
      inFile = argv[1];
   }else{
      logFile = "img.log";
      inFile = INPUT_FILENAME;
   }

   std::fstream olog;
   olog.open(logFile, std::fstream::in | std::fstream::out | std::fstream::app);
	
   int flag;
	
	int mode = 1;
	int i;

	/* detection parameters */
	float scaleFactor = 1.2;
	int minNeighbours = 1;


	printf("\n-- Entering main function --\r\n");


	MyImage imageObj;
	MyImage *image = &imageObj;

	flag = readPgm(inFile, image);
	if (flag == -1)
	{
		printf( "Unable to open input image\n");
		return 1;
	}

	printf("-- Image Loaded- Width: %d, Height: %d\r\n", image->width, image->height);

	printf("-- Loading cascade classifier\r\n");

	myCascade cascadeObj;
	myCascade *cascade = &cascadeObj;
	MySize minSize = {20, 20};
	MySize maxSize = {0, 0};

	/* classifier properties */
	cascade->n_stages=25;
	cascade->total_nodes=2913;
	cascade->orig_window_size.height = 24;
	cascade->orig_window_size.width = 24;

	printf("\n-- Cascade Classifier Info: \n \tStages: %d\n \tTotal Filters: %d\n \tWindow Size: Width: %d, Height: %d\r\n", cascade->n_stages, cascade->total_nodes, 
                                                                                                                                  cascade->orig_window_size.width, cascade->orig_window_size.height);

	readTextClassifier();
	//readTextClassifierForGPU();
    readTextClassifierForGPUPinned();
	
   std::vector<MyRect> result;

	printf("\n-- Detecting faces\r\n");

	result = detectObjects(image, minSize, maxSize, cascade, scaleFactor, minNeighbours, olog);

	for(i = 0; i < result.size(); i++ )
	{
		MyRect r = result[i];
		drawRectangle(image, r);
	}

	printf("\n-- Saving output --\r\n"); 
	flag = writePgm((char *)OUTPUT_FILENAME, image); 

	printf("-- Image saved --\r\n");

	/* delete image and free classifier */
	releaseTextClassifier();
	//releaseTextClassifierGPU();
	releaseTextClassifierGPUPinned();
   
   freeImage(image);
   olog.close();

	return 0;
}
