#!/bin/bash

TOP = /home/vinayg/red_ninjas/project
BIN = $TOP/bin



export CUDA_PROFILE=1

cp $BIN/facedetect $TOP/facedetect
cd $TOP/facedetect
./facedetect group.pgm img.log
rm -rf facedetect

