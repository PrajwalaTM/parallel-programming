#! /bin/bash

TOP=/home/vinayg/red_ninjas/project
FD=$TOP/facedetect
BIN=$TOP/bin/facedetect-optim


b1=1024
b2=512
b3=256
b4=128
b5=64
b6=32
b7=25


rm -rf $b1.stat $b2.stat $b3.stat $b4.stat $b5.stat $b6.stat $b7.stat




